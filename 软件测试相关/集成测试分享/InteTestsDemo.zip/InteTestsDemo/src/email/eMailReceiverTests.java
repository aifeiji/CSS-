package email;

import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.GreenMailUtil;
import org.junit.*;
import sun.plugin2.message.Message;

import static org.junit.Assert.*;

/**
 * Created by T540p on 2015/10/13.
 */
public class eMailReceiverTests {

	private GreenMail greenMail;
	private eMailReceiver receiver;
	@BeforeClass
	protected void setUpBeforeClass() {
		greenMail = new GreenMail();
		greenMail.setUser("test", "test");
		greenMail.start();
		receiver = new eMailReceiver();
	}

	@AfterClass
	protected void tearDownAfterClass() {
		greenMail.stop();
	}

	@Test
	public void receive_should_receive_all_mail_messages() throws Exception {
		GreenMailUtil.sendTextEmailTest("to@dummy.com", "from@dummy1.com",
				"Hello world!", "This is a dummy message");
		GreenMailUtil.sendTextEmailTest("to@dummy.com", "from@dummy2.com",
				"Hello world!", "This is another dummy message");
		Message[] messages = receiver.receive("test", "test");

		assertNotNull(messages);
		assertEquals(messages.length, 2);
	}

}
