package email;

import com.icegreen.greenmail.util.GreenMail;
import org.junit.*;

import javax.mail.Address;
import javax.mail.Message;

import static junit.framework.TestCase.*;

/**
 * Created by T540p on 2015/10/13.
 */
public class eMailSenderTests {

	private eMailSender sender;
	private GreenMail greenMail;
	@BeforeClass
	protected void setUpBeforeClass() {
		greenMail = new GreenMail();
		greenMail.start();
		sender = new eMailSender();
	}

	@AfterClass
	protected void tearDownAfterClass() {
		greenMail.stop();
	}

	@Test
	public void send_should_send_mail_message() throws Exception {

		sender.send("Hello world!", "This is a dummy message",
				"from@dummy.com", "to@dummy.com");
		Message[] messages = greenMail.getReceivedMessages();

		assertNotNull(messages);
		assertEquals(messages.length, 1);

		Message message = messages[0];
		Address[] froms = message.getFrom();

		assertNotNull(froms);
		assertEquals(froms.length, 1);
	}

}
