package email;

import sun.plugin2.message.Message;

/**
 * Created by T540p on 2015/10/13.
 */
public class eMailReceiver {

	public Message[] receive(String test, String test1) {
		return new Message[2];
	}
}
