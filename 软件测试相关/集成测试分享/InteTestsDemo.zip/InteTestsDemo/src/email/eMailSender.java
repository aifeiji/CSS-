package email;

import sun.plugin2.message.Message;

/**
 * Created by T540p on 2015/10/13.
 */
public class eMailSender {

	public void send(String s1,String s2,String s3,String s4){

	}
}
