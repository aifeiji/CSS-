package ftp;

import org.junit.*;
import org.mockftpserver.fake.FakeFtpServer;
import org.mockftpserver.fake.UserAccount;
import org.mockftpserver.fake.filesystem.FileEntry;
import org.mockftpserver.fake.filesystem.UnixFakeFileSystem;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;

/**
 * Created by T540p on 2015/10/13.
 */
public class ftpTests {
	private UnixFakeFileSystem fs;
	private FakeFtpServer server;
	private FtpGetComponent client;

	@BeforeClass
	protected void setUpBeforeClass() {

		client = new FtpGetComponent("localhost", 2021, "test", "test");
		fs = new UnixFakeFileSystem();
		server = new FakeFtpServer();
		server.setServerControlPort(2021);
		server.setFileSystem(fs);
		server.addUserAccount(new UserAccount("test", "test", "/"));
		server.start();
	}

	@AfterClass
	protected void tearDownAfterClass() {
		server.stop();
	}

	@Test
	public void get_file_should_contain_hello_world() throws IOException {
		String tmpDir = System.getProperty("java.io.tmpdir");
		Path path = Paths.get(tmpDir, "dummy.txt");
		Files.deleteIfExists(path);
		fs.add(new FileEntry("/dummy.txt", "Hello world!"));

		client.getTextFile(path.toString(), "/dummy.txt");

		assertTrue(Files.exists(path));
		List<String> lines = Files.readAllLines(path);
		assertNotNull(lines);
		assertFalse(lines.isEmpty());
		assertEquals(lines.size(), 1);
		String line = lines.iterator().next();
		assertEquals(line, "Hello world!");
	}

}
