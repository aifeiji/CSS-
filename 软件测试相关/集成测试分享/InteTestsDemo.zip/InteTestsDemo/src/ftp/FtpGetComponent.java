package ftp;

import sun.net.ftp.FtpClient;

/**
 * Created by T540p on 2015/10/13.
 */
public class FtpGetComponent {
	private String server;
	private int port;
	private String username;
	private String pwd;
	private FtpClient client;

	public FtpGetComponent(String server, int port, String username, String pwd) {
		this.server = server;
		this.port = port;
		this.username = username;
		this.pwd = pwd;

	}

	public void getTextFile(String remotePath, String loaclPath) {

	}

}
