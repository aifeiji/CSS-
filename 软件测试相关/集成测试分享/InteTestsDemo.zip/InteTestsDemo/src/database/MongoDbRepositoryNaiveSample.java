import com.mongodb.*;

import java.net.UnknownHostException;
import java.util.*;

public class MongoDbRepositoryNaiveSample {

	private DB database;

	public MongoDbRepositoryNaiveSample(String host, int port)
			throws UnknownHostException {
			MongoClient client = new MongoClient(host, port);
			database = client.getDB("customerDb");
	}

	public List<Customer> getAllCustomers() {
		DBCollection collection = database.getCollection("customer");
		DBCursor cursor = collection.find();
		List<Customer> customers = new ArrayList<>();

		try {
			while (cursor.hasNext()) {
				DBObject object = cursor.next();
				Integer id = (Integer) object.get("_id");
				Customer customer = new Customer();
				customer.setId((long) id);
				customers.add(customer);
			}
		} finally {
			cursor.close();
		}

		return customers;
	}
}