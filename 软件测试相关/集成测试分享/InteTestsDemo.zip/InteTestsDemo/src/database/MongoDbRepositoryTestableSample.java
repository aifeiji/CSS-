package database;

/**
 * Created by T540p on 2015/10/14.
 */
public class MongoDbRepositoryTestableSample {
	private DB database;

	public MongoDbRepositoryTestableSample(MongoClient client) {
		database = client.getDB("customerDb");
	}

}
