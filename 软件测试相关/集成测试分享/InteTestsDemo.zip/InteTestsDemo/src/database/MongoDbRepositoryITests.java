import com.github.fakemongo.Fongo;
import com.mongodb.*;
import database.Customer;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.UnknownHostException;
import java.util.List;

import static com.mongodb.WriteConcern.ACKNOWLEDGED;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class MongoDbRepositoryITests {

	private MongoDbRepositoryTestableSample repository;

	private MockMongoClient client;


	@BeforeTest
	protected void setUp() throws UnknownHostException {
		Fongo fongo = new Fongo("main");
		client = MockMongoClient.create(fongo);
		repository = new MongoDbRepositoryTestableSample(client);
	}

	@Test
	public void should_return_all_customers() {
		DB database = client.getDB("customerDb");
		DBCollection collection = database.getCollection("customer");
		for (int i = 0; i < 5; i++) {
			collection.insert(ACKNOWLEDGED, new BasicDBObject("_id", i));
		}

		List<Customer> customer = repository.getAllCustomers();
		assertNotNull(customer);
		assertEquals(customer.size(), 5);
	}
}