package filesystem;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class iOBeforeJava7 {

	public void writeContent(String content, File file) {

		if (file.isDirectory()) {
			throw new RuntimeException("Cannot write content to directory");
		}

		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		} else if (!file.canWrite()) {
			throw new RuntimeException("Cannot write to file");
		}

		try (FileWriter writer = new FileWriter(file)) {
			writer.write(content);
			writer.flush();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public String readContent(File file) {

		if (file.isDirectory()) {
			throw new RuntimeException("Cannot read directory content");
		}

		if (!file.canRead()) {
			throw new RuntimeException("Cannot read file");
		}

		try (FileReader reader = new FileReader(file)) {
			StringBuffer buffer = new StringBuffer();
			int ch;
			while ((ch = reader.read()) != -1) {
				buffer.append((char) ch);
			}
			return buffer.toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
