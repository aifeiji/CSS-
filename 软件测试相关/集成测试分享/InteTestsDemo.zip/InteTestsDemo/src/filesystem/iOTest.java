package filesystem;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;

import static org.junit.Assert.assertEquals;

/**
 * Created by T540p on 2015/10/13.
 */
public class iOTest {

	private iOBeforeJava7 legacy;

	@Before
	public void setup()	{
		legacy = new iOBeforeJava7();
	}

	@After
	public void tearDown(){
		legacy = null;
	}

	@Test
	public void read_file_should_retrieve_content() throws Exception {

		String dir = System.getProperty("java.io.tmpdir");
		File file = new File(dir, "dummy.txt");

		file.createNewFile();
		FileOutputStream fos = new FileOutputStream(file);
		fos.write("Hello world!".getBytes());

		String content = legacy.readContent(file);

		assertEquals(content, "Hello world!");
	}
}
