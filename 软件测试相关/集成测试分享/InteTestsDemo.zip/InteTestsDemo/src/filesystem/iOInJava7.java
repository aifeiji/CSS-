package filesystem;


import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class iOInJava7 {

	public void writeContent(String content, Path path) {

		if (!Files.exists(path)) {
			try {
				Files.createFile(path);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		if (Files.isDirectory(path)) {
			throw new RuntimeException("Cannot write into directory");
		}

		if (!Files.isWritable(path)) {
			throw new RuntimeException("No write permissions");
		}

		try {
			Files.write(path, content.getBytes());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public String readContent(Path path) {

		if (!Files.exists(path)) {
			throw new RuntimeException("File doesn't exist");
		}

		if (Files.isDirectory(path)) {
			throw new RuntimeException("Cannot read from a directory");
		}

		if (!Files.isReadable(path)) {
			throw new RuntimeException("No read permissions");
		}

		try {
			List<String> lines =  Files.readAllLines(path);
			StringBuffer buffer = new StringBuffer();
			lines.stream().forEach(line -> buffer.append(line));
			return buffer.toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}