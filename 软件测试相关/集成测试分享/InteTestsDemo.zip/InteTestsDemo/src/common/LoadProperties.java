package common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

/**
 * Created by T540p on 2015/10/13.
 * ����ʱ������ʹ�ò�����-Dapp.properties=/path/to/file.properties.
 */
public class LoadProperties {

	private static final Logger LOGGER =
			     	Logger.getLogger(LoadProperties.class.getName());
	private Properties properties = new Properties();

	public LoadProperties(){
		String path = System.getProperty("app.properties","/default/file.properties");
		File file = new File(path);
		try(FileInputStream stream = new FileInputStream(file)){
			properties.load(stream);
		}catch (FileNotFoundException e){
			LOGGER.warning("Properties file does not exist");
			throw new RuntimeException(e);
		}catch(IOException e){
			LOGGER.warning("Could not close Properties file");
		}

	}

	public String getValueof(String key){
		return properties.getProperty(key);
	}
}
