/**
 * DataZoom component entry
 */
define(function (require) {

    require('./dataZoom/DataZoomModel');
    require('./dataZoom/DataZoomView');
    require('./dataZoom/dataZoomProcessor');
    require('./dataZoom/dataZoomAction');

});