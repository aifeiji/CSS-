(function () {

    require.config({
        baseUrl: '../',
        paths: {
            'echarts': './echarts2',
            'echarts-x': './echarts-x',
            'grapher': './grapher',
            'data': './data',
            'img': './img'
        }
    });


})();